package ProductService;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.Models.Login_Info;
import com.Models.Sme_Trainer_Details;
import com.dao.OrclDatabase;

public class Services 
{
	static Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
	public static void CreateTrainer(Sme_Trainer_Details trainer) throws SQLException
	{
		try{
			if(con!=null)
			{
				PreparedStatement ps= con.prepareStatement(
						"Insert into sme_trainer_details(Role_Name, Employee_Id,First_Name,Last_Name,D_O_B,Gender,Contact_number,Email, skill_1, skill_2, skill_3,username,password)"
						+ " values(?,?, ?, ?, ?, ?, ?,?,?,?,?,?,?)");
				ps.setString(1, "Trainer");
				ps.setInt(2, trainer.getEmployee_Id());
				ps.setString(3, trainer.getFirst_name());
				ps.setString(4, trainer.getLast_name());
				ps.setString(5, trainer.getD_O_B());
				ps.setString(6, trainer.getGender());
				ps.setString(7, trainer.getContact_number());
				ps.setString(8, trainer.getEmail());
				ps.setString(9, trainer.getSkill_1());
				ps.setString(10, trainer.getSkill_2());
				ps.setString(11, trainer.getSkill_3());
				ps.setString(12, trainer.getUsername());
				ps.setString(13, trainer.getPassword());
				ps.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void UpdateDetails(Sme_Trainer_Details trainer) throws SQLException
	{
		try{
			if(con!=null)
			{
				if(trainer.getPassword().equals("") ||trainer.getPassword().equals(null) )
				{
					String query = "update sme_trainer_details set MIDDLE_NAME=?, PERMANENT_ADDRRESS=? ,RESIDENTIAL_ADDRRESS=?,contact_number=? where username=?";
					PreparedStatement ps1 = con.prepareStatement(query);
					ps1.setString(1, trainer.getMiddle_name());
					ps1.setString(2, trainer.getPermanent());
					ps1.setString(3, trainer.getResidential());
					ps1.setString(4, trainer.getContact_number());
					ps1.setString(5, trainer.getUsername());
					ps1.executeUpdate();
				}
				if(!trainer.getPassword().isEmpty())
				{
					String query = "update sme_trainer_details set MIDDLE_NAME=?, PERMANENT_ADDRRESS=? , RESIDENTIAL_ADDRRESS=?,contact_number=?, password=? where username=?";
					PreparedStatement ps2 = con.prepareStatement(query);
					ps2.setString(1, trainer.getMiddle_name());
					ps2.setString(2, trainer.getPermanent());
					ps2.setString(3, trainer.getResidential());
					ps2.setString(4, trainer.getContact_number());
					ps2.setString(5, trainer.getPassword());
					ps2.setString(6, trainer.getUsername());
					ps2.executeUpdate();
					query = "update login_info set password=? where username=?";
					PreparedStatement ps3 = con.prepareStatement(query);
					ps3.setString(1, trainer.getPassword());
					ps3.setString(2, trainer.getUsername());
					ps3.executeUpdate();
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void CreateSme(Sme_Trainer_Details trainer) throws SQLException
	{
		try{
			if(con!=null)
			{
				PreparedStatement ps= con.prepareStatement(
						"Insert into sme_trainer_details(Role_Name, Employee_Id,First_Name,Last_Name,D_O_B,Gender,Contact_number,Email, skill_1, skill_2, skill_3,username,password)"
						+ " values(?,?, ?, ?, ?, ?, ?, ?,?,?,?,?,?)");
				ps.setString(1, "SME");
				ps.setInt(2, trainer.getEmployee_Id());
				ps.setString(3, trainer.getFirst_name());
				ps.setString(4, trainer.getLast_name());
				ps.setString(5, trainer.getD_O_B());
				ps.setString(6, trainer.getGender());
				ps.setString(7, trainer.getContact_number());
				ps.setString(8, trainer.getEmail());
				ps.setString(9, trainer.getSkill_1());
				ps.setString(10, trainer.getSkill_2());
				ps.setString(11, trainer.getSkill_3());
				ps.setString(12, trainer.getUsername());
				ps.setString(13, trainer.getPassword());
				ps.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void CreateLoginInfo(Login_Info li) throws SQLException
	{
		try{
			if(con!=null)
			{
				PreparedStatement ps= con.prepareStatement(
						"Insert into login_info values(?,?, ?)");
				ps.setString(1, li.getUsername());
				ps.setString(2, li.getPassword());
				ps.setString(3, li.getRolename());
				
				ps.executeUpdate();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static ResultSet getSmeTrainerList() throws SQLException
	{
		String query = "Select * from sme_trainer_details where First_name!='admin' ORDER BY LOWER(First_Name) ASC" ;
		PreparedStatement ps=con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet getAvailableTrainers() throws SQLException
	{
		LocalDate now = LocalDate.now();  
		Date date = java.sql.Date.valueOf(now);
       	String query = "SELECT sme_trainer_details.Employee_id,sme_trainer_details.First_Name,"
       			+ "sme_trainer_details.skill_1,sme_trainer_details.skill_2,sme_trainer_details.skill_3,"
       			+ "sme_trainer_details.Rating FROM sme_trainer_details "
       			+ "INNER JOIN mapping ON "
       			+ "sme_trainer_details.Employee_id = mapping.Employee_id "
       			+ "INNER JOIN leavetable ON mapping.Employee_id = leavetable.Employee_id "
       			+ "WHERE ? < mapping.From_Date or ? >mapping.To_Date "
       			+ " AND ( ? < leavetable.From_Date or ? >leavetable.To_Date) "
       			+ "Or mapping.From_date='null' ORDER BY FIRST_NAME";
       	PreparedStatement ps=con.prepareStatement(query);   
       	ps.setString(1,date.toString());
        ps.setString(2,date.toString());
        ps.setString(3,date.toString());
        ps.setString(4,date.toString());
        ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet getMappedTrainerList() throws SQLException
	{
		LocalDate now = LocalDate.now();  
		Date date = java.sql.Date.valueOf(now); 
		String query = "SELECT sme_trainer_details.Employee_id,sme_trainer_details.First_Name,"
				+ "sme_trainer_details.skill_1,sme_trainer_details.skill_2,sme_trainer_details.skill_3,"
				+ "sme_trainer_details.rating  FROM sme_trainer_details "
				+ "INNER JOIN mapping ON "
				+ "sme_trainer_details.Employee_id = mapping.Employee_id "
				+ "INNER JOIN leavetable ON mapping.Employee_id = leavetable.Employee_id "
				+ "WHERE ? >= mapping.From_Date and ? <= mapping.To_Date  OR "
				+ "( ? >= leavetable.From_Date and ? <=leavetable.To_Date) OR "
				+ "(?<mapping.From_Date ) ORDER BY FIRST_NAME";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1,date.toString());
		ps.setString(2,date.toString());
		ps.setString(3,date.toString());
		ps.setString(4,date.toString());
		ps.setString(5,date.toString());
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet MappedTrainerSearch(String fdate, String tdate) throws SQLException
	{
		String query = "SELECT sme_trainer_details.Employee_id,sme_trainer_details.First_Name,"
       			+ "sme_trainer_details.skill_1,sme_trainer_details.skill_2,sme_trainer_details.skill_3,"
       			+ "sme_trainer_details.Rating FROM sme_trainer_details "
       			+ "INNER JOIN mapping ON "
       			+ "sme_trainer_details.Employee_id = mapping.Employee_id "
       			+ "INNER JOIN leavetable ON mapping.Employee_id = leavetable.Employee_id "
       			+ "WHERE ? < mapping.From_Date or ? >mapping.To_Date "
       			+ " AND ( ? < leavetable.From_Date or ? >leavetable.To_Date) ORDER BY FIRST_NAME";
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1,fdate);
		ps.setString(2,tdate);
		ps.setString(3,fdate);
		ps.setString(4,tdate);
		ResultSet rs = ps.executeQuery();
		return rs;
		
	}
	public static ResultSet getLeaveList() throws SQLException
	{
		LocalDate now = LocalDate.now();  
		Date date = java.sql.Date.valueOf(now); 
		String query = "SELECT Employee_Id,From_Date,To_Date,reason from leavetable "
				+ "where ? >= From_Date and ? <= To_Date  OR "
				+ "(?<leavetable.From_Date ) ORDER BY From_Date";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setString(1,date.toString());
        ps.setString(2,date.toString());
        ps.setString(3,date.toString());
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet setLeave(int employee_id, String fdate, String tdate, String reason) throws SQLException
	{
		String query = "Insert into leavetable values(?,?,?,?)";
        PreparedStatement ps=con.prepareStatement(query);
        ps.setInt(1,employee_id);
        ps.setString(2,fdate);
        ps.setString(3,tdate);
        ps.setString(4,reason);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	
	public static ResultSet getTrainerDetails(String employeeid) throws SQLException
	{
		String query = "Select * from sme_trainer_details where employee_id=? ORDER BY First_name" ;
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, employeeid);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet TrainerDetails(String username) throws SQLException
	{
		String query = "Select * from sme_trainer_details where username=? ORDER BY First_name" ;
		PreparedStatement ps=con.prepareStatement(query);
		ps.setString(1, username);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet getAssignments() throws SQLException
	{
		LocalDate now = LocalDate.now();  
		Date date = java.sql.Date.valueOf(now); 
   	   	String query = "SELECT * from mapping where ?>From_Date ORDER BY From_Date";
   	   	PreparedStatement ps=con.prepareStatement(query);   
   	   	ps.setString(1,date.toString());
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static void MapTrainer(int employee_id, String fdate, String tdate, String skill, String location) throws SQLException
	{
		String query = "insert into mapping values(?,?,?,?,?)";
		PreparedStatement ps =con.prepareStatement(query); 
		ps.setInt(1, employee_id);
		ps.setString(2, fdate);
		ps.setString(3, tdate);
		ps.setString(4, skill);
		ps.setString(5, location);
		ps.executeUpdate();
	}
	public static ResultSet GetMonthlyMapping(String employeeid,String month,String year) throws SQLException
	{
		String startdate = "01-"+month+year;
		String enddate = "31-"+month+year;
		String query = "Select from_date,to_date from mapping where (from_date BETWEEN ? and ?  OR to_date BETWEEN ? and ? )AND employee_id=?";
		PreparedStatement ps =con.prepareStatement(query); 
		ps.setString(1, startdate);
		ps.setString(2, enddate);
		ps.setString(3, startdate);
		ps.setString(4, enddate);
		ps.setString(5, employeeid);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet EmployeeOnLeave(String date, String employeeid) throws SQLException
	{
		String query = "Select * from leavetable where from_date<=? AND to_date>=? AND employee_id=?";
		PreparedStatement ps =con.prepareStatement(query); 
		ps.setString(1, date);
		ps.setString(2, date);
		ps.setString(3, employeeid);
		ResultSet rs = ps.executeQuery();
		return rs;
	}
	public static ResultSet GetSkills() throws SQLException
	{
		String query = "Select skill_name from skill";
		PreparedStatement ps = con.prepareStatement(query);
		ResultSet rs= ps.executeQuery();
		return rs;
	}
	public static void SendMail(String From_Address,String To_Address,String Details) throws SQLException
	{
		String query = "Insert into mail values(?,?,?)";
		PreparedStatement ps = con.prepareStatement(query);
		ps.setString(1, From_Address);
		ps.setString(2, To_Address);
		ps.setString(3, Details);
		ps.executeQuery();
	}
	
}
