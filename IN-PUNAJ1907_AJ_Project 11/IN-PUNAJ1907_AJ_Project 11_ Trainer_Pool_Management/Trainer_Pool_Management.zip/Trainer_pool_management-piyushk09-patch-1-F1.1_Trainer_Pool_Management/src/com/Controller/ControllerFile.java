package com.Controller;

import java.awt.Window;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

import ProductService.Services;

public class ControllerFile extends HttpServlet
{
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		boolean flag=false,found=false;
		String role=null,username=null,password=null;
		HttpSession session  = req.getSession();
		session.setMaxInactiveInterval(30);
		String path = req.getContextPath();
		
		if(session!=null)
		{
			username=(String)session.getAttribute("username");
			password=(String)session.getAttribute("password");
			role=(String)session.getAttribute("role" );
			flag=true;
			try
			{
				if(role.equals("ADMIN") &&role!=("TRAINER")&&role!=("SME"))
				{
					if(flag)
						req.getRequestDispatcher("views/adminmain.jsp?username="+username+"&password="+password+"&role="+role).forward(req, res);
					else
						req.getRequestDispatcher("views/Admin_Login.jsp?errmsg=Invalid Username or Password..").forward(req, res);
				}
				if(role.equals("SME") &&role!=("ADMIN")&&role!=("TRAINER"))
				{
					if(flag)
						req.getRequestDispatcher("views/SmeMain.jsp?username="+username+"&password="+password+"&role="+role).forward(req, res);
					else
						req.getRequestDispatcher("views/Sme_Login.jsp").forward(req, res);
				}
				if(role.equals("TRAINER") &&role!=("ADMIN")&&role!=("SME"))
				{
					if(flag)
					{
						req.getRequestDispatcher("views/TrainerMain.jsp").forward(req, res);
					}
					else
					{
						req.getRequestDispatcher("views/Trainer_Login.jsp").forward(req, res);
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		else
		{
			req.getRequestDispatcher("views/Welcome.jsp").forward(req, res);
		}
		
	}
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
			doPost(req, res);
	}
	
}
