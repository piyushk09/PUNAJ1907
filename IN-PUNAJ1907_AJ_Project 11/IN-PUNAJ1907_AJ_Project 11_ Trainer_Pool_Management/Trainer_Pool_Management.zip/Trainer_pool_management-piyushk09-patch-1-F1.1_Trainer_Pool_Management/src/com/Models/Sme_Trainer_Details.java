package com.Models;

import java.io.Serializable;
public class Sme_Trainer_Details implements Serializable 
{

	private
	String first_name,last_name, D_O_B,gender,role_name, email, skill_1, skill_2, skill_3,username,password; 
	int Employee_id;
	String contact_number;
	String middle_name, residential,permanent,cpassword1,cpassword2;
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	int Employee_Id;
	public Sme_Trainer_Details(){}
	public Sme_Trainer_Details(int Employee_Id,String first_name,
			String last_name,String D_O_B,String gender,String contact_number
			,String role_name,String email,String skill_1,String skill_2,String skill_3,String username,String password)
	{
		this.Employee_Id=Employee_Id;
		this.first_name=first_name;
		this.last_name=last_name;
		this.D_O_B=D_O_B;
		this.gender=gender;
		this.contact_number=contact_number;
		this.role_name=role_name;
		this.email=email;
		this.skill_1=skill_1;
		this.skill_2=skill_2;
		this.skill_3=skill_3;
		this.username=username;	
		this.password=password;
	}
	
	public String getSkill_2() {
		return skill_2;
	}
	public void setSkill_2(String skill_2) {
		this.skill_2 = skill_2;
	}
	public String getSkill_3() {
		return skill_3;
	}
	public void setSkill_3(String skill_3) {
		this.skill_3 = skill_3;
	}
	public Sme_Trainer_Details(String middle_name, String permanent, String residential,String contact_number, String username,String password)
	{
		this.middle_name=middle_name;
		this.residential=residential;
		this.permanent=permanent;
		this.contact_number=contact_number;
		this.username=username;	
		this.password=password;
	}
	public String getMiddle_name() {
		return middle_name;
	}
	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}
	public String getResidential() {
		return residential;
	}
	public void setResidential(String residential) {
		this.residential = residential;
	}
	public String getPermanent() {
		return permanent;
	}
	public void setPermanent(String permanent) {
		this.permanent = permanent;
	}
	public String getCpassword1() {
		return cpassword1;
	}
	public void setCpassword1(String cpassword1) {
		this.cpassword1 = cpassword1;
	}
	public String getCpassword2() {
		return cpassword2;
	}
	public void setCpassword2(String cpassword2) {
		this.cpassword2 = cpassword2;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEmployee_Id() {
		return Employee_Id;
	}
	public void setEmployee_Id(int employee_Id) {
		Employee_Id = employee_Id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	
	public String getD_O_B() {
		return D_O_B;
	}
	public void setD_O_B(String d_O_B) {
		D_O_B = d_O_B;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	public String getRole_name() {
		return role_name;
	}
	public void setRole_name(String role_name) {
		this.role_name = role_name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSkill_1() {
		return skill_1;
	}
	public void setSkill_1(String skill_1) {
		this.skill_1 = skill_1;
	}
	public int getEmployee_id() {
		return Employee_id;
	}
	public void setEmployee_id(int employee_id) {
		Employee_id = employee_id;
	}
	public String getContact_number() {
		return contact_number;
	}
	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}
	
}
