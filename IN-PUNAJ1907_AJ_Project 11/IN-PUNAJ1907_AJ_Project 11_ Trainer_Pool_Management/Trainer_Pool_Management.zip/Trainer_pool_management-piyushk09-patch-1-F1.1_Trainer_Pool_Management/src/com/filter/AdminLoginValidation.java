package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

public class AdminLoginValidation implements javax.servlet.Filter 
{
	public void destroy() 
	{}
	
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain doChain) throws IOException, ServletException 
	{
		Connection con =OrclDatabase.connect("oracle", "system", "cognizant");
		String role = "ADMIN";boolean flag=false;
		String username = req.getParameter("username");
		String password = req.getParameter("password");
		
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null)
		{
			try 
			{
				req.setAttribute("role", role);
				
				String query = "Select * from sme_trainer_details where role_name='ADMIN'";
				PreparedStatement ps = con.prepareStatement(query);
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					if(username.equals(rs.getString(10))&&password.equals(rs.getString(11)))
					{
						session.setAttribute("username", username);
						session.setAttribute("password", password);
						session.setAttribute("role", role);
						flag=true;
						req.getRequestDispatcher("Admin_Login.do?username="+username+"&password="+password+"&role="+role).forward(req, res);
						
					}
				}
				if(flag==false)
				{
					req.getRequestDispatcher("views/Admin_Login.jsp?errmsg=Invalid Username or Password..").forward(req, res);
				}
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	public void init(FilterConfig arg0) throws ServletException 
	{
	}
}
