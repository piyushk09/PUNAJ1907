package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

public class ForgotController extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		final Random generator = new Random();
		int x =100000 + generator.nextInt(900000);
		
		String s =Integer.toString(x);		
		String username = (String)req.getAttribute("username");
		String role = (String)req.getAttribute("role");
		
		HttpSession session = req.getSession();
		session.setAttribute("username", username);
		session.setAttribute("role", role);

		req.getSession().setAttribute("password", s);
		String password = (String)req.getSession().getAttribute("password");
		try 
		{
			Connection con = OrclDatabase.connect("oracle", "system", "cognizant");

			PreparedStatement ps = con.prepareStatement("update sme_trainer_details set password=? where username=?");
			ps.setString(1, password);
			ps.setString(2, username);
			ps.executeUpdate();
			
			ps = con.prepareStatement("update login_info set password=? where username=?");
			ps.setString(1, password);
			ps.setString(2, username);
			ps.executeUpdate();
			
			if(role.equalsIgnoreCase("ADMIN"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Admin_Login.jsp?msg=Password has been sent to you on your Registered Email!");
				rd.forward(req, res);
			}
			if(role.equalsIgnoreCase("TRAINER"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Trainer_Login.jsp?msg=Password has been sent to you on your Registered Email!");
				rd.forward(req, res);
			}
			if(role.equalsIgnoreCase("SME"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Sme_Login.jsp?msg=Password has been sent to you on your Registered Email!");
				rd.forward(req, res);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
				
		

		
	}
}
