package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;


public class ChangePasswordController extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		String password = req.getParameter("password");
		String username = (String) session.getAttribute("username");
		String role = (String) session.getAttribute("role");
		try
		{
			Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
			//**********For sme_trainer_details Table*********//
			String query = "update sme_trainer_details set password = ? where username = ?";
			PreparedStatement ps = con.prepareStatement(query);
			ps.setString(1, password);
			ps.setString(2, username);
			ps.executeUpdate();
			//**********For sme_trainer_details Table*********//
			
			
			//***************For Login_Info Table*************//
			String query1 = "update Login_Info set password = ? where username = ?";
			ps = con.prepareStatement(query1);
			ps.setString(1, password);
			ps.setString(2, username);
			ps.executeUpdate();
			//***************For Login_Info Table*************//
			
			if(role.equalsIgnoreCase("ADMIN"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Admin_Login.jsp?msg=Password Changed successfully!");
				rd.forward(req, res);
			}
			if(role.equalsIgnoreCase("TRAINER"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Trainer_Login.jsp?msg=Password Changed successfully!");
				rd.forward(req, res);
			}
			if(role.equalsIgnoreCase("SME"))
			{
				session.invalidate();
				RequestDispatcher rd = req.getRequestDispatcher("views/Sme_Login.jsp?msg=Password Changed successfully!");
				rd.forward(req, res);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
	}
}
