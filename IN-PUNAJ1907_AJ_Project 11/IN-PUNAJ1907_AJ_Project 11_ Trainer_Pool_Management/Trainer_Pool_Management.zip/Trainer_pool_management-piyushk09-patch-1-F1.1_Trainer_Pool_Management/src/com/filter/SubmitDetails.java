package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

import ProductService.Services;

public class SubmitDetails implements javax.servlet.Filter
{
	@Override
	public void destroy() {}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain dochain) throws IOException, ServletException 
	{
		int employee_id = Integer.parseInt((String)req.getParameter("empid"));
		String location = req.getParameter("location");
		String fdate = req.getParameter("fdate");
		String tdate = req.getParameter("tdate");
		String skill = req.getParameter("skill");
		
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		HttpSession session = request.getSession();
		String username = (String)session.getAttribute("username");
		String role= (String)session.getAttribute("role");
		try
		{
			Services.MapTrainer(employee_id, fdate, tdate, skill, location);
			req.getRequestDispatcher("views/map.jsp?msg=Trainer Mapped Successfully..");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {}
}
