package com.filter;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class EditProfileController extends HttpServlet
{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doPost(req, res);
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		String username = (String)req.getSession().getAttribute("username");
		String role = (String)req.getSession().getAttribute("role");
		String firstname = (String)req.getAttribute("firstname");
		String lastname = (String)req.getAttribute("lastname");
		String email = (String)req.getAttribute("email");
		String middlename = (String)req.getAttribute("middlename");
		String permanent = (String)req.getAttribute("permanent");
		String residential = (String)req.getAttribute("residential");
		String mobile = (String)req.getAttribute("mobile");
		req.setAttribute("firstname", firstname);
		req.setAttribute("lastname", lastname);
		req.setAttribute("email", email);
		req.getRequestDispatcher("views/EditProfile.jsp?firstname="+firstname+"&lastname="+lastname+"&email="+email+"&middlename="+middlename+"&permanent="+permanent+"&residential="+residential+"&mobile="+mobile).forward(req, res);
	}
}
