package com.filter;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import ProductService.Services;

public class SendMail implements javax.servlet.Filter 
{
	@Override
	public void destroy() {}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain DoChain) throws IOException, ServletException 
	{
		try 
		{
			String From_Address = req.getParameter("From_Address");
			String To_Address = req.getParameter("To_Address");
			String SkillDropdown_1 = req.getParameter("SkillDropdown_1");
			String From_Date = req.getParameter("From_Date");
			String To_Date = req.getParameter("To_Date");
			String Details = "Skill 1::"+SkillDropdown_1+" From_Date::"+From_Date+" To_Date::"+To_Date;
			Services.SendMail(From_Address, To_Address, Details);
			req.getRequestDispatcher("SmeRequestForm.jsp?msg=Mail Sent Successfully..");
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {}

}
