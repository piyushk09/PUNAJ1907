package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Models.Sme_Trainer_Details;
import com.dao.OrclDatabase;

import ProductService.Services;

public class Edit_Profile_data implements javax.servlet.Filter 
{
	@Override
	public void destroy() {}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain dochain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response= (HttpServletResponse)res;
		HttpSession session =request.getSession();
		String username = (String)session.getAttribute("username");
		String MIDDLE_NAME = req.getParameter("middle");
		String mobile = req.getParameter("mobile");
		String landline = req.getParameter("landline");
		String house1 = req.getParameter("house1");
		String street1 = req.getParameter("street1");
		String landmark1 = req.getParameter("landmark1");
		String city1 = req.getParameter("city1");
		String house2 = req.getParameter("house2");
		String street2 = req.getParameter("street2");
		String landmark2 = req.getParameter("landmark2");
		String city2 = req.getParameter("city2");
		String country1 = req.getParameter("country1");
		String country2 = req.getParameter("country2");
		String password = req.getParameter("password");
		String currentpassword = req.getParameter("currentpassword");
		String residential = house1+street1+landmark1+city1;
		String permanent = house2+street2+landmark2+city2;
		boolean flag=false;
		try
		{
			Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
			String query = "Select * from sme_trainer_details";
			PreparedStatement ps = con.prepareStatement(query);
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				if(currentpassword.equals(rs.getString(11)))
				{
					Sme_Trainer_Details trainer = new Sme_Trainer_Details(MIDDLE_NAME, permanent, residential,mobile,username,password);
					Services.UpdateDetails(trainer);
					flag=true;
					req.getRequestDispatcher("views/TrainerMain.jsp").forward(req, res);
				}
			}
			if(flag=false)
			{
				req.getRequestDispatcher("views/Trainer_Login.jsp?msg=Invalid Username or Password..");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {}

}
