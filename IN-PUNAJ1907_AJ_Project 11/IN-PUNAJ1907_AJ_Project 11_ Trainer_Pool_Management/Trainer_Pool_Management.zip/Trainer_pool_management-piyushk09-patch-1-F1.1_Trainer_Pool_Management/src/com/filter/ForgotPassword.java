package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;

import com.dao.OrclDatabase;

/**
 * Servlet Filter implementation class forgotPassword
 */
@WebFilter("/forgotPassword")
public class ForgotPassword implements Filter {

    /**
     * Default constructor. 
     */
    public ForgotPassword() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		
		String username = "",role="";
		try{
			Connection con  = OrclDatabase.connect("oracle", "system", "cognizant");
			String q = "select * from sme_trainer_details";
			
			PreparedStatement ps = con.prepareStatement(q);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				if(request.getParameter("email").equals(rs.getString(9)))
				{
					username = rs.getString(10);
					role = rs.getString(8);
				}
			}
			
			if(username.equals(""))
			{
				RequestDispatcher rd = request.getRequestDispatcher("views/Forgot_Password.jsp?msg=User Doesn't Exist!");
				rd.include(request, response);
			}
			else
			{
				request.setAttribute("username", username);
				request.setAttribute("role", role);
				chain.doFilter(request, response);
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		//chain.doFilter(request, response);
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
