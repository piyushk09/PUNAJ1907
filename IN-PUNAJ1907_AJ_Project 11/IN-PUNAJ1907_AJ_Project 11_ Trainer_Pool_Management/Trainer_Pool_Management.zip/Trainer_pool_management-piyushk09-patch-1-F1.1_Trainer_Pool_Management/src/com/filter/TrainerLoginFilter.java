package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

public class TrainerLoginFilter implements javax.servlet.Filter 
{
	@Override
	public void destroy() {}
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain doChain) throws IOException, ServletException 
	{
		String role="TRAINER",username=req.getParameter("username"), password=req.getParameter("password");
		boolean found=false;
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		HttpSession session = request.getSession();
		if(session.getAttribute("username")==null)
		{
			req.setAttribute("role", role);
			try 
			{
				Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
				PreparedStatement ps;
				ps = con.prepareStatement("Select * from sme_trainer_details where role_name!='ADMIN' and role_name!='SME'");
				ResultSet rs = ps.executeQuery();
				while(rs.next())
				{
					if(username.equals(rs.getString(10)) &&password.equals(rs.getString(11)))
					{
						session.setAttribute("username", username);
						session.setAttribute("password", password);
						session.setAttribute("role", role);
						found=true;
						req.getRequestDispatcher("Trainerlogin.do?username="+username+"&password="+password+"&role="+role).forward(req, res);
					}
				}
				if(found==false)
					req.getRequestDispatcher("views/Trainer_Login.jsp?errmsg=Invalid Username or Password.").forward(req, res);
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {}
}
