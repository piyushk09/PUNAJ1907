package com.filter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrclDatabase;

public class EditProfile implements javax.servlet.Filter 
{
	@Override
	public void destroy() {}
	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain dochain) throws IOException, ServletException 
	{
		String firstname="",lastname="",email="",middlename="",permanent="", residential="",mobile="";
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response = (HttpServletResponse)res;
		HttpSession session  = request.getSession();
		String username = (String)session.getAttribute("username");
		String role = (String)session.getAttribute("role");
		try 
		{
			Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
			PreparedStatement ps = con.prepareStatement("Select * from sme_trainer_details");
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				if(role.equalsIgnoreCase((rs.getString(8))) && username.equalsIgnoreCase(rs.getString(10)))
				{
					req.setAttribute("firstname", 	rs.getString(2));
					req.setAttribute("middlename", 	rs.getString(3));
					req.setAttribute("lastname", 	rs.getString(4));
					req.setAttribute("mobile", 		rs.getString(7));
					req.setAttribute("email", 		rs.getString(9));
					req.setAttribute("permanent", 	rs.getString(14));
					req.setAttribute("residential", rs.getString(15));
					firstname = 	(String)req.getAttribute("firstname");
					middlename = 	(String)req.getAttribute("middlename");
					lastname = 		(String)req.getAttribute("lastname");
					mobile = 		(String)req.getAttribute("mobile");
					email = 		(String)req.getAttribute("email");
					permanent = 	(String)req.getAttribute("permanent");
					residential = 	(String)req.getAttribute("residential");
					req.getRequestDispatcher("EditProfileController.do?firstname="+firstname+"&middlename="+middlename+"&lastname="+lastname+"&mobile="+mobile+"&email="+email+"&username="+username+"&permanent="+permanent+"&residential="+residential).forward(req, res);
				}
			}
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
	}
	@Override
	public void init(FilterConfig arg0) throws ServletException {} 
}