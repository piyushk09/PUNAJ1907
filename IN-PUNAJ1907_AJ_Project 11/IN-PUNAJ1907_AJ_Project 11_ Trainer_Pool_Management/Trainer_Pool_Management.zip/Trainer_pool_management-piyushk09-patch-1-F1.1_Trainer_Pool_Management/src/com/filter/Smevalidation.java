package com.filter;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpSession;

import com.Models.Login_Info;
import com.Models.Sme_Trainer_Details;
import com.dao.OrclDatabase;

import ProductService.Services;

public class Smevalidation implements javax.servlet.Filter
{

	public void init(FilterConfig arg0) throws ServletException 
	{}
	
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain doChain) throws IOException, ServletException 
	{
		int Employee_Id=Integer.parseInt(req.getParameter("employeeid"));
		String username=req.getParameter("username");
		String email=req.getParameter("email");
		String Contact_number =req.getParameter("contact");
		boolean flag=false;
		try
		{
			Connection con = OrclDatabase.connect("oracle", "system", "cognizant");
			PreparedStatement ps = con.prepareStatement("Select * from sme_trainer_details");
			ResultSet rs = ps.executeQuery();
			while(rs.next())
			{
				if(Employee_Id==rs.getInt(1) || email.equals(rs.getString(9)) || username.equals(rs.getString(10)))
				{
					RequestDispatcher rd = req.getRequestDispatcher("views/Sme_Registration.jsp?errmsg=User Already Exists!!!!");
					rd.include(req, res);
					flag=true;
				}
			}
			if(flag==false)
			{
				String marital_status = "Unmarried";
				String rolename = "SME";
				String fname = req.getParameter("firstname");
				String lname = req.getParameter("lastname");
				String DOB= req.getParameter("dob");
				String gender = req.getParameter("gender");
				String skill_1 = req.getParameter("skill1");
				String skill_2 = req.getParameter("skill2");
				String skill_3 = req.getParameter("skill3");
				String password = req.getParameter("password");
				Sme_Trainer_Details emp=new Sme_Trainer_Details(Employee_Id, fname,  lname,
						DOB, gender, Contact_number,rolename,email, skill_1, skill_2, skill_3,username,password);
				Login_Info li = new Login_Info(username, password, rolename);
				
				Services.CreateSme(emp);
				Services.CreateLoginInfo(li);
				req.setAttribute("username", username);
				req.setAttribute("password", password);
				req.setAttribute("role", rolename);
				req.getRequestDispatcher("views/Sme_Login.jsp?msg=SME Created Successfully..").forward(req, res);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void destroy() 
	{}
}
