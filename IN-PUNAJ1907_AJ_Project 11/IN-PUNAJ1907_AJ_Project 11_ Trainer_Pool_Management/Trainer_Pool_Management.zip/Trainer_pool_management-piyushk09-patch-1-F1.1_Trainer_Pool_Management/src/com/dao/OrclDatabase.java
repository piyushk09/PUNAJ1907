package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class OrclDatabase 
{
	public static Connection connect(String dbtype, String uname, String password)
	{
		Connection con = null;
		try{
			if(dbtype.equals("oracle"))
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", uname,password);
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return con;
	}

	
}
