create table skill
(
	Skill_Id number not null unique,
	Skill_Name varchar2(30) primary key
);
create table mail
(
	ToAddress varchar2(30) not null,
	FromAddress varchar2(30) not null, 
	Details varchar2(200) not null
);


create table Login_Info
(
username varchar2(30) primary key,
password varchar2(30) not null,
Role_name varchar2(10) not null ,
foreign key(username) references sme_trainer_details(username)
);

create table sme_trainer_details
(
	Employee_Id number(6) primary key,
	First_Name varchar2(30) not null,
	Middle_Name varchar2(30),
	Last_Name varchar2(30) not null,
	D_O_B varchar2(15) not null,
	Gender varchar2(8) not null,
	Contact_number varchar2(10) not null,
	Role_Name varchar2(20) not null,
	Email varchar2(30) unique not null,
	username varchar2(30) not null unique,
	password varchar2(30) not null,
	Skill_1 varchar2(20) not null,
	Marital_Status varchar2(10),
	Permanent_Addrress varchar2(80),
	Residential_Addrress varchar2(80),
	Pan_Number varchar2(10),
	Qualification varchar2(25),
	Certification varchar2(25),
	Certificate_Description varchar2(25),
	Organization varchar2(30),
	Skill_2 varchar2(20),
	Skill_3 varchar2(20),
	Rating number(5)
);

create table mapping(
	Employee_id number(6) not null,
	From_Date varchar2(16),
	To_Date varchar2(16),
	Skill varchar2(15) ,
	Location varchar2(15) ,
	Foreign key(Employee_id) references sme_trainer_details(Employee_id)
);
create table LeaveTable(
	Employee_id number(6) not null unique,
	From_Date varchar2(16),
	To_Date varchar2(16),
	Reason varchar2(50) not null,
	Foreign key(Employee_id) references sme_trainer_details(Employee_id)
);

insert into sme_trainer_details(
Employee_Id,First_name,Last_name,D_O_B,Gender,Contact_Number,Role_Name,Email,Username,Password,Skill_1
)values(
&Employee_Id,&Fname,&Lname, &D_O_B, &gender,&mobno,&Role,&email,&username, &password,&skill_1
);
insert into login_info values(&username, &password,&role_name);
insert into Role values(&Employee_Id, &Role_Name);
insert into Skill values(&Skill_id, &Skill_Name);

alter table sme_trainer_details add (skill_1 varchar2(20),skill_2 varchar2(20),skill_3 varchar2(20));
alter table sme_trainer_details drop column skill_1; 


desc sme_trainer_details;
desc Role;